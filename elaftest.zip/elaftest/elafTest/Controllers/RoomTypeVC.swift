//
//  RoomTypeVC.swift
//  elafTest
//
//  Created by Hamza on 3/11/20.
//  Copyright © 2020 Hamza. All rights reserved.
//

import UIKit

class RoomTypeVC: UIViewController {

    var model : HotelData!
    var roomData : [Translation] = []
    var hotelImagesData : [HotelImages] = []
    var passHotelId : Int?
    
    @IBOutlet weak var hotelImage: UIImageView!
    @IBOutlet weak var hotelName: UILabel!
    @IBOutlet weak var hotelDescription: UILabel!
    @IBOutlet weak var hotelAddress: UILabel!
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
       super.viewDidLoad()
       addLeftBarIcon()
       populateData()
       tableView.tableFooterView = UIView(frame: .zero)
       self.tableView.separatorColor = UIColor.clear
    }
    
    func populateData(){
        for data in roomData {
            if data.id == passHotelId {
                hotelName.text = data.name
                hotelAddress.text = data.address
                hotelDescription.text = data.description
            }
        }
        for imgs in hotelImagesData {
            if imgs.hotel_id == passHotelId {
                if let url = URL(string: imgs.image) {
                  hotelImage.af_setImage(withURL: url)
                }
            }
        }
        
        
        
        let filtered = hotelImagesData.filter{ $0.hotel_id == passHotelId }
        filtered.first?.image.forEach({ (im) in
            print(im)
        })
 
    
        
    }
}

extension RoomTypeVC : UITableViewDelegate , UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return hotelImagesData.count
    }
    
   func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "roomTypeId", for: indexPath) as? RoomTypeCell {
            cell.model = hotelImagesData[indexPath.row]
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let secondVC = self.storyboard?.instantiateViewController(identifier: "BookingInfoVCid") as? BookingInfoVC {
        //secondVC.model = hotelListData[indexPath.row]
        self.navigationController?.pushViewController(secondVC, animated: true)
        }
    }
}
