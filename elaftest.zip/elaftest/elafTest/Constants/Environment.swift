//
//  Environment.swift
//  elafTest
//
//  Created by Apple on 4/9/20.
//  Copyright © 2020 Hamza. All rights reserved.
//

import Foundation
import UIKit

struct Environment {
    static let baseURL = "http://elafapp.arpatech.com/api/v1"
    static let apiToken = "SXY9Sm1x5gMe7PzDwogtPT8q8AnXeRtnqHMRnu4tkrKeI5Uas5yA4CTeRk9T"
    static var user : User?
}

